# Copyright (c) 2026 [SELLER]. All rights reserved.
# Licensed to a single purchaser under the terms in LICENSE.md.
# Redistribution or resale of this source, in whole or in part, is not permitted.
#
# One-command setup. Checks for Node, then starts the bridge in the foreground
# so you can see the dashboard URL and token immediately. Run
# adapters\windows-task.ps1 afterward if you want it to start automatically
# at login instead.

$ErrorActionPreference = 'Stop'

$node = Get-Command node -ErrorAction SilentlyContinue
if (-not $node) {
    Write-Error "Node.js 18+ is required. Install it from https://nodejs.org and re-run this script."
    exit 1
}

$version = (& node --version) -replace 'v', ''
$major = [int]($version.Split('.')[0])
if ($major -lt 18) {
    Write-Error "Node $version found, but 18+ is required."
    exit 1
}

Write-Host "Starting MultiConnect: Zapier/Webhook Bridge..."
Write-Host ""
node "$PSScriptRoot\bin\bridge.mjs" start
